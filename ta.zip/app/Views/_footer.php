<footer id="footer" class="mt-5">
    <div class="footer-top pt-4">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 justify-content-center">
                    <h4 class="text-center">Ikuti Kami</h4>
                    <div class="social-links text-center text-md-right pt-3 pt-md-0">
                        <a href="https://wa.me/+6282237046626" class="whatsapp"><i class="bx bxl-whatsapp"></i></a>
                        <a href="https://www.facebook.com/profile.php?id=100075001511094" class="facebook"><i class="bx bxl-facebook"></i></a>
                        <a href="https://www.instagram.com/tulisnake/" class="instagram"><i class="bx bxl-instagram"></i></a>
                        <a href="https://www.youtube.com/channel/UC5VWeXFJSDQ7PQrK2SFv7Ow/featured" class="youtube"><i class="bx bxl-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class=" container py-3">
        <div class="d-flex justify-content-center text-center">
            <div class="copyright">
                &copy; 2022 <strong><span>Pura Penataran Agung Dalem Ped. </span></strong>. All Rights Reserved. | by <a href="javascript:;">A A GDE AGUS AMANDA PUTRA</a>
            </div>
        </div>
    </div>
</footer>
<div id="preloader"></div>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="<?= base_url(); ?>/assets/vendor/purecounter/purecounter.js"></script>
<script src="<?= base_url(); ?>/assets/vendor/aos/aos.js"></script>
<script src="<?= base_url(); ?>/assets/vendor/chart.js/chart.min.js"></script>
<script src="<?= base_url(); ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url(); ?>/assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="<?= base_url(); ?>/assets/vendor/php-email-form/validate.js"></script>
<!-- Template Main JS File -->
<script src="<?= base_url(); ?>/assets/js/main.js"></script>


</body>

</html>
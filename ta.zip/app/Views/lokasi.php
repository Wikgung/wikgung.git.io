<?php include"_head.php";?>

<body>

    <!-- ======= Header ======= -->
    <?php include "_header.php"; ?>
    <!-- End Header -->

    	<!--=========== Alur Persembahyangan ==========-->
	<section class="card d-flex mt-5">
		<div class="container position-relative" data-aos="zoom-in" data-aos-delay="100">
			<nav aria-label="breadcrumb">
				<ol class="breadcrumb">
					<li class="breadcrumb-item active" aria-current="page">
						<h1>Lokasi </h1>
					</li>
				</ol>
			</nav>

			<nav aria-label="breadcrumb">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="<?= base_url('home') ?>">Home</a></li>
					<li class="breadcrumb-item active" aria-current="page">Lokasi </li>
				</ol>
			</nav>

		</div>
	</section><!-- End Kontak -->

    <br><br><div class=" container position-relative">
    <center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3944.1436117613116!2d115.51606964993599!3d-8.677890090719636!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd27252f333e4c5%3A0xa2c815d4bb44e517!2sPura%20Penataran%20Ped!5e0!3m2!1sid!2sid!4v1639620848528!5m2!1sid!2sid" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe></center>
   </div> <br>

        <!-- ======= Footer ======= -->
        <?php include "_footer.php" ?>
    <!-- End Footer -->

   